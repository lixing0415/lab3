This is a test program for menu.

Build Procedure:
	$ make
    $./test

If this test program is successful, it will print like this:

test report
Testcase Number1 F - TC1 JudgeCmd
Testcase Number2 F - TC2 CreateCmd
Testcase Number3 F - TC3 DeleteCmd
Testcase Number4 F - TC4 UpdateCmd
Testcase Number5 F - TC5 SearchCmd

