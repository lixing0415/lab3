/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Lixing (Come from Mengning's teaching videoes)                       */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test function                                                        */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  This is a test  program                                              */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Writed by Lixing, after studying Mengning's teaching videoes,2014/09/30
 *
 */

#include<stdio.h>
#include"linktable.h"
#include"menu.h"

#define debug

int results[6] = {1,0,0,0,0,0};
char * info[6] =
{
    "test report",
    "TC1 JudgeCmd",
    "TC2 CreateCmd",
    "TC3 DeleteCmd",
    "TC4 UpdateCmd",
    "TC5 SearchCmd"
};

int main()
{
    int i;
    char * cmd = "test"; 
    char * s = "This is a test.";
    
    int ret = JudgeCmd(cmd);
    if(ret == SUCCESS)
    {
        debug("TC1 SUCCESS\n");
        results[1] = 1;
    }

    tLinkTable * p = CreateCmd(cmd, s); 
    if(p == NULL)
    {
        debug("TC2 SUCCESS\n");
        results[2] = 1;
    }
    
    ret = DeleteCmd(cmd);
    if(ret == SUCCESS)
    {
        debug("TC3 SUCCESS\n");
        results[3] = 1;       
    }
     
    p = UpdateCmd(cmd, s);
    if(p == NULL)
    {
        debug("TC4 SUCCESS\n");
        results[4] = 1;
    }

    ret = SearchCmd(cmd);
    if(ret == SUCCESS)
    {
        debug("TC5 SUCCESS\n");
        results[5] = 1;       
    }

    /* test report */
    printf("test report\n");
    for(i=1;i<6;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}
