
/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Lixing (Come from Mengning's teaching videoes)                       */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu function                                                        */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/30                                                           */
/*  DESCRIPTION           :  This is a menu source program                                        */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Writed by Lixing, after studying Mengning's teaching videoes,2014/09/30
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"
#include "menu.h"

int Help();
int Quit();
int V();
tLinkTable * head;

int JudgeCmd(char * cmd)
{
    return SUCCESS;
}

tLinkTableNode* FindCmd(tLinkTable * head, char * cmd)
{
    return NULL;
}

int ShowAllCmd(tLinkTable * head)
{
    return SUCCESS;
}
tLinkTable* CreateCmd(char * cmd, char *desc)
{
    return NULL;
}
int DeleteCmd(char * cmd)
{
    return SUCCESS;
}
tLinkTable* UpdateCmd(char * cmd, char * desc)
{
    return NULL;
}

int SearchCmd(char * cmd)
{ 
    FindCmd(head, cmd);    
    return SUCCESS;
}

int Help()
{
    ShowAllCmd(head);
    return 0;
}

int Quit()
{
    exit(0);
}

int V()
{
    return 0;
}
